<html>
<head>
  <title>Blank Document</title>
  <!-- Latest compiled and minified CSS -->
  <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.4/css/jquery-ui.min.css">
    <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.0.3/css/font-awesome.min.css">

    <!-- Optional theme -->
    <!-- PAS DIT AAN NAAR JE EIGEN CSS BESTANDEN DIE JE WIL INCLUDEN-->
<!--     <link rel="stylesheet" href="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/css/bootstrap-theme.min.css"> -->

    <!-- Current doc CSS -->
  <link rel="stylesheet" href="index.css">  <!-- PAS DIT AAN NAAR JE EIGEN CSS BESTAND-->


</head>
<body>
  <div class="container">
        <div class="row">
            <form class="banner form-horizontal mx-auto col-md-4" method="post" action="" style='background-color: #d9e5f1;padding: 50px;margin-top: 50px;margin-bottom: 50px;'>
      <div class='titel'>QuirkCMS</div>
        <div class="form-group">
          <div class="col-sm-12">
            <div class="input-group">
              <input type="text" class="form-control" name="email" placeholder="je mail adres"/>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-12">
            <div class="input-group">
              <input type="password" class="form-control" name="ww" placeholder="je wachtwoord"/>
            </div>
          </div>
        </div>
        <div class="form-group">
          <div class="col-sm-12">
            <button type="submit" class="btn btn-lg btn-block btnCMS" name="submitKnopLogin" >Log in</button>
          </div>
        </div>
    </form>
        </div>
  </div>

    <!-- Latest compiled and minified JavaScript -->
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/jqueryui/1.10.4/jquery-ui.min.js"></script>
    <script src="http://netdna.bootstrapcdn.com/bootstrap/3.1.1/js/bootstrap.min.js"></script>

    <!-- Current doc JS -->
    <script src="index.js"></script>  <!-- PAS DIT AAN NAAR JE EIGEN JAVASCRIPT BESTAND(EN)-->
</body>
</html>