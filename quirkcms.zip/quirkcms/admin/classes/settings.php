<?php


   define("USER" , "root");
   define("PSSWD", "");
   define("DB", "quirkcms");
   define("SERVER", "127.0.0.1");

	/* Geef hier het path, als je niet op de root folder van je website zit !*/
	define("MASTERPATH", "quirkcms");
	
