<?php
    $volume; 
    $number_of_speakers;
    $merk;
    $wattage;
?>
