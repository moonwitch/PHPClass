<?php
    $cowboyName = "Jack Leatherwood"; //string
    $wapens = array("lasso", "pistool", "mes"); //array
    $age = 42; //integer
    $hasMoustache = true; //boolean
    $weight = 69.45; //float
    $bounty = 0; //integer

    var_dump($weight);
?>