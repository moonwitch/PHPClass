<?php
    $love_potion_name = "Potion of Eternal Devotion"; //string
    $prijs_in_euro = 14.75; //float
    $one_true_love_name = "Ziggy"; // string
    $shake_before_use = false; //boolean 

    $magic_spell = "Hocus Pocus!"; //string
    $potion_ingredients = ["Rose petals", "Unicorn tears", "A pinch of dragon sneeze"]; //array
?>