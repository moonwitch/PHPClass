<?php
    // Fix typo in Echo statement and fix string literal
    // echo "Cola"; // Ex 6 stop cola from showing
    // I don't like either - huuuuge Ginger Beer fan here
    // New line and add missing ;
    print "limonade";
// Add terminator
?>