<?php 
   /* Database settings */
   define("USER" , "root");
   define("PSSWD", "");
   define("DB", "quirkcms");
   define("SERVER", "localhost");

	/* Geef hier het path, als je niet op de root folder van je website zit !*/
	define("MASTERPATH", "quirkcms");
?>