<div class="testimonials">
    <h2>Wat onze klanten zeggen</h2>
    <div class="testimonial-grid">
        <div class="testimonial">
            <div class="quote">"Uitstekende service! Onze tuin is volledig getransformeerd en precies zoals we het hadden gewenst."</div>
            <div class="client">— Familie Janssens, Hasselt</div>
        </div>
        <div class="testimonial">
            <div class="quote">"Zeis en Bijl heeft onze verwaarloosde tuin omgetoverd tot een prachtige buitenruimte waar we elke dag van genieten."</div>
            <div class="client">— Karlien Verstraeten, Leuven</div>
        </div>
    </div>
    <a href="portfolio.php" class="button primary">Bekijk ons portfolio</a>
</div>