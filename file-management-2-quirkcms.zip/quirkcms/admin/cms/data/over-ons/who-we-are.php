<div class="about-intro">
    <h2>Wie zijn wij?</h2>
    <p class="lead">Zeis en Bijl is een familiebedrijf met meer dan 20 jaar ervaring in het creëren en onderhouden
        van prachtige buitenruimtes in heel Limburg.</p>
</div>