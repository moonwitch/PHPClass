<div class="projects-showcase">
    <h3>Recente projecten</h3>
    <div class="grid">
        <div class="project-item">
            <img src="https://picsum.photos/id/225/300/200" alt="Tuinproject in Geetbets">
            <p>Moderne familietuin in Geetbets</p>
        </div>
        <div class="project-item">
            <img src="https://picsum.photos/id/292/300/200" alt="Tuinproject in Herk-de-Stad">
            <p>Landelijke tuin in Herk-de-Stad</p>
        </div>
        <div class="project-item">
            <img src="https://picsum.photos/id/91/300/200" alt="Tuinproject in Tienen">
            <p>Onderhoudsvriendelijke stadstuin in Tienen</p>
        </div>
    </div>
</div>