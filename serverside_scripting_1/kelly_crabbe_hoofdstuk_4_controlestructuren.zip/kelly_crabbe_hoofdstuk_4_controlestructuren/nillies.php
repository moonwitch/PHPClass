<?php

// Oef 11
$birthYear = 2010;

if ($birthYear >= 2000 && $birthYear <= 2009) {
    echo "Je bent geboren in de jaren 2000.";
} else {
    echo "Je bent niet geboren in de jaren 2000.";
}

?>