<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aftellen</title>
</head>
<body>
    <?php
    $countdown = 100;
    while ($countdown >= 0) {
        echo $countdown . "<br>";
        $countdown--;
    }
?>
</body>
</html>