<?php
// multiplication table of 4; from 10 to 1
for ($i = 10; $i >= 1; $i--) {
    echo "$i x 4 = " . 4 * $i . "<br>";
}
?>