<?php
    $value = 1;
    while ($value <= 100) {
        echo $value . "<br>";
        $value *= 2;
    }
?>