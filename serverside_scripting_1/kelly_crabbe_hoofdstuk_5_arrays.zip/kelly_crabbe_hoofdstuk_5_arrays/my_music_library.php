<?php // Define the array of classic rock songs
$classicRockSongs = [
    "Bohemian Rhapsody - Queen",
    "Stairway to Heaven - Led Zeppelin",
    "Hotel California - Eagles",
    "Sweet Child O' Mine - Guns N' Roses",
    "Back in Black - AC/DC",
    "Free Bird - Lynyrd Skynyrd",
]; 
// Concatenate and display the message
echo $classicRockSongs[0] ." is het eerste lied dat in mijn muziek bibliotheek werd opgenomen."; ?>