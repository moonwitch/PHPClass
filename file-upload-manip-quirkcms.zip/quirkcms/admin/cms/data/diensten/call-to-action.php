        <div class="cta-content">
    <h2>Klaar om uw tuin te transformeren?</h2>
    <p>Neem contact met ons op voor een <b>gratis adviesgesprek en offerte.</b></p>
    <a href="contact.php" class="btn-primary">Contact opnemen</a>
</div>    