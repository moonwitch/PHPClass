<h2>Wat onze klanten zeggen</h2>
<div class="testimonials">
    <div class="testimonial">
        <blockquote>
            "Zeis en Bijl heeft onze tuin volledig getransformeerd. Het team was professioneel,
            punctueel en leverde uitstekend werk. Sterk aanbevolen!"
        </blockquote>
        <cite>— Jan Peeters, Hasselt</cite>
    </div>

    <div class="testimonial">
        <blockquote>
            "Zeer tevreden over het onderhoudscontract dat we hebben. Onze tuin ziet er het hele jaar
            perfect uit zonder dat we er zelf tijd aan moeten besteden."
        </blockquote>
        <cite>— Marie Claessens, Genk</cite>
    </div>
</div>