<div class="values-section">
    <h3>Onze waarden</h3>
    <div class="values-grid">
        <div class="value-card">
            <h4>Kwaliteit</h4>
            <p>We streven naar de hoogste standaarden in alles wat we doen, van materialen tot uitvoering.</p>
        </div>

        <div class="value-card">
            <h4>Duurzaamheid</h4>
            <p>We werken met respect voor de natuur en zoeken altijd naar milieuvriendelijke oplossingen.</p>
        </div>

        <div class="value-card">
            <h4>Betrouwbaarheid</h4>
            <p>We komen onze afspraken na en zijn transparant in onze communicatie en prijzen.</p>
        </div>

        <div class="value-card">
            <h4>Creativiteit</h4>
            <p>We denken out-of-the-box om unieke oplossingen te vinden die bij uw specifieke situatie passen.</p>
        </div>
    </div>
</div>