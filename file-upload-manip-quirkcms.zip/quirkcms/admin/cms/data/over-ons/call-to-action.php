<div class="cta-content">
    <h2>Werken bij Zeis en Bijl?</h2>
    <p>We zijn altijd op zoek naar getalenteerde mensen die ons team willen versterken.</p>
    <a href="contact.php" class="btn-primary">Neem contact op</a>
</div>